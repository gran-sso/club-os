<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/krishnadaspnair/Documents/Skysys/Products/malabar-club/vendor/filament/support/resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>