<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/krishnadaspnair/Documents/Skysys/Products/malabar-club/vendor/filament/widgets/resources/views/components/widget.blade.php ENDPATH**/ ?>