<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-5">
        <!-- Header -->
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div class="flex items-center gap-2.5">
                <div class="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center justify-center font-bold text-lg">
                    🍽️
                </div>
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white tracking-tight">Contractor &amp; Counter Shifts</h3>
                    <p class="text-[11px] text-slate-500">Catering payables and open cash registers</p>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(url('/admin/contractor-settlements/contractor-settlement-batches')); ?>" class="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1">
                    <span>Settlements</span>
                    <span>&rarr;</span>
                </a>
            </div>
        </div>

        <!-- Section 1: Food Catering Contractor Daily Accumulator -->
        <div class="p-3.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800/80 space-y-2">
            <div class="flex items-center justify-between">
                <div>
                    <span class="text-[10px] font-bold uppercase tracking-wider text-slate-500">Today's Qualified Food Sales</span>
                    <div class="text-lg font-extrabold text-slate-900 dark:text-white font-mono mt-0.5">
                        ₹<?php echo e($todayFoodRupees); ?>

                    </div>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($latestBatch): ?>
                    <?php
                        $rawStatus = $latestBatch->status instanceof \BackedEnum ? $latestBatch->status->value : (string) $latestBatch->status;
                        $batchStatusColor = match ($rawStatus) {
                            'settled', 'paid' => 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
                            'partially_paid' => 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
                            'approved' => 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30',
                            default => 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30',
                        };
                    ?>
                    <div class="text-right">
                        <span class="text-[10px] font-bold uppercase tracking-wider text-slate-500"><?php echo e($latestBatch->contractor?->name ?? 'Catering'); ?> Batch</span>
                        <div class="mt-0.5">
                            <span class="px-2 py-0.5 rounded-full text-[10px] font-bold border <?php echo e($batchStatusColor); ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $rawStatus))); ?> (₹<?php echo e(number_format($latestBatch->net_payable_paise / 100, 2)); ?>)
                            </span>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <p class="text-[11px] text-slate-500 leading-tight">
                Cash, digital, and member wallet food orders automatically pool for next morning contractor settlement. Unused wallet balances are excluded.
            </p>
        </div>

        <!-- Section 2: Active Counter Shifts -->
        <div class="space-y-2.5">
            <div class="flex items-center justify-between text-xs">
                <div class="flex items-center gap-1.5">
                    <span>⚡</span>
                    <span class="font-bold uppercase tracking-wider text-slate-500 text-[10px]">Active POS Stations</span>
                </div>
                <a href="<?php echo e(url('/admin/shifts')); ?>" class="text-[11px] font-semibold text-amber-600 dark:text-amber-400 hover:underline">
                    All Shifts &rarr;
                </a>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($staleShiftsCount > 0): ?>
                <div class="p-2.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-700 dark:text-rose-400 flex items-center justify-between">
                    <span>⚠️ <strong><?php echo e($staleShiftsCount); ?></strong> unclosed shift(s) from previous date requires cash balancing!</span>
                    <a href="<?php echo e(url('/admin/shifts')); ?>" class="underline font-bold text-[11px]">Audit</a>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($openShifts->isEmpty()): ?>
                <div class="p-3 bg-slate-50 dark:bg-slate-950/40 rounded-xl border border-slate-100 dark:border-slate-800 text-xs text-slate-500 text-center">
                    No counter shifts are currently open. Open a station to begin cashier billing.
                </div>
            <?php else: ?>
                <div class="divide-y divide-slate-100 dark:divide-slate-800/80">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $openShifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <div class="py-2 flex items-center justify-between text-xs">
                            <div class="flex items-center gap-2">
                                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                <div>
                                    <span class="font-bold text-slate-900 dark:text-white"><?php echo e($shift->counter?->name ?? 'POS Station'); ?></span>
                                    <span class="text-[11px] text-slate-500 block">Cashier: <?php echo e($shift->cashier?->name ?? 'Staff'); ?></span>
                                </div>
                            </div>
                            <div class="text-right">
                                <span class="font-mono text-xs font-semibold text-slate-900 dark:text-white">Float: ₹<?php echo e(number_format($shift->opening_float_paise / 100, 2)); ?></span>
                                <span class="text-[10px] text-slate-400 block font-mono"><?php echo e($shift->created_at?->format('h:i A')); ?></span>
                            </div>
                        </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>

<?php /**PATH /Users/krishnadaspnair/Documents/Skysys/Products/malabar-club/resources/views/filament/widgets/contractor-and-shift-status.blade.php ENDPATH**/ ?>