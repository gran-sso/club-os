<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="space-y-6">
        <!-- Top Banner: Environment & Safety Notice -->
        <div class="p-4 bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-300 rounded-2xl text-amber-950 text-xs flex items-start gap-3.5 shadow-2xs">
            <div class="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 font-bold flex items-center justify-center shrink-0 shadow-2xs">
                ⚠️
            </div>
            <div class="leading-relaxed">
                <span class="font-bold text-amber-900 uppercase tracking-wide block">Hardware &amp; Accounting Integration Safety Notice</span>
                External hardware adapters (Access Control turnstiles, biometric gates, and Tally Prime XML bridge) are designed with failsafe isolation.
                You can configure the on-premise Tally LAN IP and test communication directly from this panel without touching server files.
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- 1. Tally Prime Outbox & Sync Status -->
            <div class="p-6 bg-white border border-slate-200/90 rounded-2xl shadow-xs space-y-5">
                <div class="flex items-center justify-between border-b border-slate-100 pb-3.5">
                    <div class="flex items-center gap-2.5">
                        <div class="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700 font-bold">
                            📑
                        </div>
                        <div>
                            <h3 class="font-bold text-sm text-slate-900 tracking-tight">Tally Prime XML Outbox Bridge</h3>
                            <span class="text-[11px] text-slate-500">Asynchronous Accounting Voucher Sync</span>
                        </div>
                    </div>
                    <span class="px-3 py-1 text-xs font-mono font-bold rounded-full <?php echo e(($tallyStatus['driver'] ?? '') === 'tally_http' ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'bg-amber-100 text-amber-900 border border-amber-300'); ?>">
                        <?php echo e($tallyStatus['label'] ?? 'SIMULATOR'); ?>

                    </span>
                </div>

                <p class="text-xs text-slate-600 leading-relaxed">
                    Outbox-backed journal synchronization guarantees that point-of-sale transactions and member balances post uninterrupted on the club server even if Tally Prime is offline. Transactions are deduplicated idempotently by journal sequence.
                </p>

                <!-- Queue Stats -->
                <div class="grid grid-cols-3 gap-3 text-center">
                    <div class="p-3.5 bg-slate-50 rounded-xl border border-slate-200 shadow-2xs">
                        <span class="block text-[10px] uppercase font-bold text-slate-500 tracking-wider">Pending Outbox</span>
                        <span class="text-2xl font-extrabold font-mono text-amber-600"><?php echo e($outboxStats['pending'] ?? 0); ?></span>
                    </div>
                    <div class="p-3.5 bg-slate-50 rounded-xl border border-slate-200 shadow-2xs">
                        <span class="block text-[10px] uppercase font-bold text-slate-500 tracking-wider">Delivered / Ack</span>
                        <span class="text-2xl font-extrabold font-mono text-emerald-600"><?php echo e($outboxStats['acknowledged'] ?? 0); ?></span>
                    </div>
                    <div class="p-3.5 bg-slate-50 rounded-xl border border-slate-200 shadow-2xs">
                        <span class="block text-[10px] uppercase font-bold text-slate-500 tracking-wider">Rejected / Errors</span>
                        <span class="text-2xl font-extrabold font-mono text-rose-600"><?php echo e($outboxStats['failed'] ?? 0); ?></span>
                    </div>
                </div>

                <div>
                    <button wire:click="dispatchOutbox" type="button"
                        class="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs rounded-xl shadow-xs shadow-amber-500/20 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2">
                        <svg width="16" height="16" class="w-4 h-4 text-slate-950 shrink-0" style="width: 16px; height: 16px; min-width: 16px;" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                        </svg>
                        <span>Dispatch Pending Outbox Messages to Tally</span>
                    </button>
                </div>

                <!-- Tally Configuration Card -->
                <div class="p-4 bg-slate-50 rounded-2xl border border-slate-200/90 space-y-4 pt-4">
                    <div class="flex items-center justify-between border-b border-slate-200 pb-2.5">
                        <div class="flex items-center gap-1.5 font-bold text-xs text-slate-900">
                            <span>⚙️</span>
                            <span>Tally Prime LAN Network Settings</span>
                        </div>
                        <span class="text-[10px] font-mono font-bold text-slate-500">
                            Target: <?php echo e($tallyStatus['endpoint'] ?? 'http://127.0.0.1:9000'); ?>

                        </span>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div class="sm:col-span-2">
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                                Tally Computer LAN IP / Hostname
                            </label>
                            <input type="text" wire:model="tallyHost" placeholder="e.g. 192.168.1.50 or 127.0.0.1"
                                class="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none">
                            <p class="text-[10px] text-slate-500 mt-1">IP address of the PC running Tally on the club network.</p>
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                                Port
                            </label>
                            <input type="number" wire:model="tallyPort" placeholder="9000"
                                class="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none">
                            <p class="text-[10px] text-slate-500 mt-1">Default: 9000</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                                Target Company Name
                            </label>
                            <input type="text" wire:model="tallyCompanyName" placeholder="e.g. Malabar Club"
                                class="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                                Integration Driver Mode
                            </label>
                            <select wire:model="tallyDriver"
                                class="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none">
                                <option value="simulator">Development Simulator (Safe Mock)</option>
                                <option value="live">Live Tally Prime HTTP (Connect to LAN)</option>
                            </select>
                        </div>
                    </div>

                    <div class="flex items-center gap-2.5 pt-1">
                        <button wire:click="saveTallySettings" type="button"
                            class="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5">
                            <span>💾</span>
                            <span>Save Configuration</span>
                        </button>
                        <button wire:click="testTallyConnection" type="button"
                            class="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5">
                            <span>🔌</span>
                            <span>Test Tally Connection</span>
                        </button>
                    </div>

                    <!-- Connection Test Feedback -->
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tallyTestResult !== null): ?>
                        <div class="p-3.5 rounded-xl border <?php echo e(($tallyTestResult['success'] ?? false) ? 'bg-emerald-50 border-emerald-300 text-emerald-900' : 'bg-rose-50 border-rose-300 text-rose-900'); ?> text-xs space-y-1">
                            <div class="font-bold flex items-center gap-1.5">
                                <span><?php echo e(($tallyTestResult['success'] ?? false) ? '✅' : '⚠️'); ?></span>
                                <span><?php echo e(($tallyTestResult['success'] ?? false) ? 'Tally Connection Succeeded' : 'Tally Connection Failed'); ?></span>
                            </div>
                            <p class="text-[11px] leading-relaxed">
                                <?php echo e($tallyTestResult['message']); ?>

                            </p>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!($tallyTestResult['success'] ?? false)): ?>
                                <div class="text-[10px] text-rose-800 pt-1 border-t border-rose-200/80">
                                    💡 <strong>Setup Checklist in Tally Prime:</strong> Press <code>F1 (Help)</code> &rarr; <code>Settings</code> &rarr; <code>Connectivity</code> &rarr; Set <code>TallyPrime acts as: Both/Server</code> and <code>Port: <?php echo e($tallyPort); ?></code>.
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <!-- 2. Access Control Hardware Simulator -->
            <div class="p-6 bg-white border border-slate-200/90 rounded-2xl shadow-xs space-y-5">
                <div class="flex items-center justify-between border-b border-slate-100 pb-3.5">
                    <div class="flex items-center gap-2.5">
                        <div class="w-9 h-9 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-bold">
                            🚪
                        </div>
                        <div>
                            <h3 class="font-bold text-sm text-slate-900 tracking-tight">Turnstiles &amp; Biometric Gate Access</h3>
                            <span class="text-[11px] text-slate-500">RFID Smartcard &amp; Guest Pass Reader</span>
                        </div>
                    </div>
                    <span class="px-3 py-1 text-xs font-mono font-bold rounded-full bg-blue-100 text-blue-900 border border-blue-300">
                        <?php echo e($accessStatus['label'] ?? 'SIMULATOR'); ?>

                    </span>
                </div>

                <p class="text-xs text-slate-600 leading-relaxed">
                    Gate reader simulator verifies active club membership, card standing, and paid guest pass authorization in real time. Fails closed automatically if deployed in a production environment.
                </p>

                <!-- Interactive Access Simulator Form -->
                <div class="space-y-3.5 pt-1">
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                            Card RFID Token or Guest Pass Code
                        </label>
                        <input type="text" wire:model="simCardNumber" placeholder="e.g. CARD-VENU-001 or GP-..."
                            class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 focus:outline-none transition-colors">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                            Target Door / Turnstile Location
                        </label>
                        <select wire:model="simFacilityCode"
                            class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 focus:outline-none transition-colors">
                            <option value="bar">Bar (Age Verification &amp; Sponsoring Check)</option>
                            <option value="card_room">Card Room (Guest Pass Required)</option>
                            <option value="gym">Gym / Health Club (Active Sports Plan)</option>
                            <option value="badminton">Badminton Court</option>
                            <option value="swimming_pool">Swimming Pool</option>
                        </select>
                    </div>
                    <button wire:click="testAccessEntry" type="button"
                        class="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2">
                        <svg width="16" height="16" class="w-4 h-4 text-amber-400 shrink-0" style="width: 16px; height: 16px; min-width: 16px;" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/>
                        </svg>
                        <span>Simulate Physical Reader Swipe / Scan</span>
                    </button>
                </div>

                <!-- Simulation Response Display -->
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($testResult !== null): ?>
                    <div class="p-4 rounded-xl border <?php echo e(($testResult['granted'] ?? false) ? 'bg-emerald-50 border-emerald-300' : 'bg-rose-50 border-rose-300'); ?>">
                        <div class="flex items-start gap-3">
                            <div class="text-xl">
                                <?php echo e(($testResult['granted'] ?? false) ? '✅' : '🚫'); ?>

                            </div>
                            <div class="space-y-1">
                                <div class="font-bold text-xs <?php echo e(($testResult['granted'] ?? false) ? 'text-emerald-900' : 'text-rose-900'); ?>">
                                    Gate Response: <?php echo e(($testResult['granted'] ?? false) ? 'ACCESS GRANTED (Barrier Unlocked)' : 'ACCESS DENIED (Barrier Locked)'); ?>

                                </div>
                                <div class="text-[11px] <?php echo e(($testResult['granted'] ?? false) ? 'text-emerald-800' : 'text-rose-800'); ?>">
                                    Reason: <?php echo e($testResult['reason'] ?? 'Verification completed.'); ?>

                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($testResult['person_name'])): ?>
                                    <div class="text-[10px] text-slate-600 font-medium">
                                        Identified Person: <strong class="text-slate-900"><?php echo e($testResult['person_name']); ?></strong>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH /Users/krishnadaspnair/Documents/Skysys/Products/malabar-club/resources/views/filament/pages/integration-status.blade.php ENDPATH**/ ?>